from .flaskr import app

app.static_folder = 'static'